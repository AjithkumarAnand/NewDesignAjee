import Sidebar from "./Component/Sidebar/Sidebar";
import Topbar from "./Component/Topbar/Topbar";
import Home from "./Component/Pages/Home";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Topbar />
      <div className="container">
        <Sidebar />
        <Home />
      </div>
    </div>
  );
}

export default App;
