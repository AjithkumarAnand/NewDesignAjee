import React from "react";
import "./Widgetlg.css";

export default function Widgetlg() {
  return (
    <div className="widgetlg">
      <span className="widgetlg_Title"> Transaction </span>
      <div className="widgetlg_Item">
        <span className="widgetlgTitle">
          <ul className="widgetlgList">
            <li className="widgetlgItem">
              <div className="widgetlgUser">
                <span className="widgetlgUsername">Anbarasu</span>
                <span className="widgetlgTitle">Mechanical Engineer</span>
              </div>
            </li>
          </ul>
        </span>
      </div>
    </div>
  );
}
