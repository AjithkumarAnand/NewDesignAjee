export const UserData = [
  {
    name: "Jan",
    "Active User": 4000,
  },
  {
    name: "Feb",
    "Active User": 4100,
  },
  {
    name: "Mar",
    "Active User": 3200,
  },
  {
    name: "April",
    "Active User": 1800,
  },

  {
    name: "May",
    "Active User": 3000,
  },
  {
    name: "June",
    "Active User": 4050,
  },
  {
    name: "July",
    "Active User": 1200,
  },
  {
    name: "Aug",
    "Active User": 6500,
  },
  {
    name: "Sep",
    "Active User": 4000,
  },
  {
    name: "Oct",
    "Active User": 5600,
  },
  {
    name: "Nov",
    "Active User": 2600,
  },
  {
    name: "Dec",
    "Active User": 1600,
  },
];
